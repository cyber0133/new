import React, {
  useCallback,
  useEffect,
  useState,
  createContext,
  useContext } from
'react';
import {
  User,
  Account,
  Trade,
  Asset,
  Signal,
  Transaction,
  TradeType } from
'./types';
import { generateId, randomPriceChange } from './utils';
// Initial Market Data
const INITIAL_ASSETS: Asset[] = [
{
  symbol: 'EURUSD',
  bid: 1.085,
  ask: 1.0852,
  spread: 2,
  digits: 5,
  change: 0.12
},
{
  symbol: 'GBPUSD',
  bid: 1.264,
  ask: 1.2643,
  spread: 3,
  digits: 5,
  change: -0.05
},
{
  symbol: 'USDJPY',
  bid: 150.2,
  ask: 150.22,
  spread: 2,
  digits: 3,
  change: 0.3
},
{
  symbol: 'AUDUSD',
  bid: 0.652,
  ask: 0.6522,
  spread: 2,
  digits: 5,
  change: -0.08
},
{
  symbol: 'XAUUSD',
  bid: 2035.5,
  ask: 2036.1,
  spread: 60,
  digits: 2,
  change: 0.85
},
{
  symbol: 'BTCUSD',
  bid: 51200.0,
  ask: 51250.0,
  spread: 5000,
  digits: 2,
  change: 2.1
},
{
  symbol: 'ETHUSD',
  bid: 2950.0,
  ask: 2952.5,
  spread: 250,
  digits: 2,
  change: 1.5
}];

interface StoreContextType {
  user: User | null;
  account: Account;
  assets: Asset[];
  trades: Trade[];
  history: Trade[];
  transactions: Transaction[];
  signals: Signal[];
  isAuthenticated: boolean;
  login: (email: string) => void;
  logout: () => void;
  executeTrade: (
  symbol: string,
  type: TradeType,
  lots: number,
  sl?: number,
  tp?: number)
  => void;
  closeTrade: (tradeId: string) => void;
  modifyTradeSLTP: (
  tradeId: string,
  sl: number | null,
  tp: number | null)
  => void;
  deposit: (amount: number, method: string) => void;
  withdraw: (amount: number, method: string) => void;
  toggleBot: (active: boolean) => void;
  botActive: boolean;
}
const StoreContext = createContext<StoreContextType | null>(null);
export function StoreProvider({ children }: {children: React.ReactNode;}) {
  const [user, setUser] = useState<User | null>(null);
  const [botActive, setBotActive] = useState(false);
  // Account State
  const [account, setAccount] = useState<Account>({
    balance: 10000,
    equity: 10000,
    margin: 0,
    freeMargin: 10000,
    marginLevel: 0,
    leverage: 100,
    type: 'DEMO',
    currency: 'USD'
  });
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [history, setHistory] = useState<Trade[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  // Mock Signals
  const [signals] = useState<Signal[]>([
  {
    id: '1',
    symbol: 'EURUSD',
    type: 'BUY',
    entry: 1.084,
    sl: 1.081,
    tp: 1.09,
    confidence: 85,
    time: Date.now()
  },
  {
    id: '2',
    symbol: 'XAUUSD',
    type: 'SELL',
    entry: 2040.0,
    sl: 2050.0,
    tp: 2020.0,
    confidence: 78,
    time: Date.now() - 3600000
  },
  {
    id: '3',
    symbol: 'GBPUSD',
    type: 'BUY',
    entry: 1.263,
    sl: 1.259,
    tp: 1.27,
    confidence: 82,
    time: Date.now() - 7200000
  },
  {
    id: '4',
    symbol: 'USDJPY',
    type: 'SELL',
    entry: 150.5,
    sl: 151.2,
    tp: 149.5,
    confidence: 71,
    time: Date.now() - 10800000
  },
  {
    id: '5',
    symbol: 'BTCUSD',
    type: 'BUY',
    entry: 51000,
    sl: 49500,
    tp: 54000,
    confidence: 88,
    time: Date.now() - 1800000
  },
  {
    id: '6',
    symbol: 'AUDUSD',
    type: 'BUY',
    entry: 0.651,
    sl: 0.647,
    tp: 0.658,
    confidence: 75,
    time: Date.now() - 5400000
  },
  {
    id: '7',
    symbol: 'ETHUSD',
    type: 'SELL',
    entry: 2960,
    sl: 3020,
    tp: 2880,
    confidence: 68,
    time: Date.now() - 9000000
  },
  {
    id: '8',
    symbol: 'XAUUSD',
    type: 'BUY',
    entry: 2030,
    sl: 2015,
    tp: 2060,
    confidence: 91,
    time: Date.now() - 14400000
  }]
  );
  // Simulation Loop (The "Broker Engine")
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Update Prices
      setAssets((prev) =>
      prev.map((asset) => {
        const newBid = randomPriceChange(asset.bid, 0.00005);
        const spreadVal = asset.spread * Math.pow(10, -asset.digits);
        return {
          ...asset,
          bid: newBid,
          ask: newBid + spreadVal
        };
      })
      );
      // 2. Update Open Trades P/L & Account Equity
      setTrades((currentTrades) => {
        if (currentTrades.length === 0) return [];
        return currentTrades.map((trade) => {
          const currentAsset = assets.find((a) => a.symbol === trade.symbol);
          if (!currentAsset) return trade;
          const currentPrice =
          trade.type === 'BUY' ? currentAsset.bid : currentAsset.ask;
          const multiplier = trade.type === 'BUY' ? 1 : -1;
          // Simplified P/L calculation: (Current - Entry) * Lots * ContractSize (assumed 100000 for forex)
          // For MVP simplicity, we'll just use a standard multiplier based on price diff
          const pipDiff = (currentPrice - trade.entryPrice) * multiplier;
          const profit = pipDiff * trade.lots * 100000; // Standard lot size assumption
          return {
            ...trade,
            currentPrice,
            profit
          };
        });
      });
    }, 1000); // Update every second
    return () => clearInterval(interval);
  }, [assets]); // Dependency on assets to get latest prices for trade calc
  // Recalculate Equity/Margin whenever trades or balance changes
  useEffect(() => {
    const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
    const usedMargin = trades.reduce(
      (sum, t) => sum + t.entryPrice * t.lots * 100000 / account.leverage,
      0
    );
    setAccount((prev) => ({
      ...prev,
      equity: prev.balance + totalProfit,
      margin: usedMargin,
      freeMargin: prev.balance + totalProfit - usedMargin,
      marginLevel:
      usedMargin > 0 ? (prev.balance + totalProfit) / usedMargin * 100 : 0
    }));
  }, [trades, account.balance, account.leverage]);
  // Bot Logic Simulation
  useEffect(() => {
    if (!botActive || !user) return;
    const botInterval = setInterval(() => {
      if (Math.random() > 0.7) {
        // 30% chance to trade every 5s
        const randomAsset = assets[Math.floor(Math.random() * assets.length)];
        const type: TradeType = Math.random() > 0.5 ? 'BUY' : 'SELL';
        executeTrade(randomAsset.symbol, type, 0.1);
      }
    }, 5000);
    return () => clearInterval(botInterval);
  }, [botActive, user, assets]);
  const login = (email: string) => {
    setUser({
      id: '1',
      email,
      name: email.split('@')[0],
      country: 'Global',
      isVerified: true
    });
  };
  const logout = () => setUser(null);
  const executeTrade = (
  symbol: string,
  type: TradeType,
  lots: number,
  sl?: number,
  tp?: number) =>
  {
    const asset = assets.find((a) => a.symbol === symbol);
    if (!asset) return;
    const entryPrice = type === 'BUY' ? asset.ask : asset.bid;
    const newTrade: Trade = {
      id: generateId(),
      symbol,
      type,
      lots,
      entryPrice,
      currentPrice: entryPrice,
      sl: sl || null,
      tp: tp || null,
      openTime: Date.now(),
      profit: 0,
      status: 'OPEN',
      commission: 0,
      swap: 0
    };
    setTrades((prev) => [newTrade, ...prev]);
  };
  const closeTrade = (tradeId: string) => {
    const trade = trades.find((t) => t.id === tradeId);
    if (!trade) return;
    const closedTrade: Trade = {
      ...trade,
      status: 'CLOSED',
      closeTime: Date.now()
    };
    setHistory((prev) => [closedTrade, ...prev]);
    setTrades((prev) => prev.filter((t) => t.id !== tradeId));
    setAccount((prev) => ({
      ...prev,
      balance: prev.balance + trade.profit
    }));
  };
  const modifyTradeSLTP = (
  tradeId: string,
  sl: number | null,
  tp: number | null) =>
  {
    setTrades((prev) =>
    prev.map((t) => {
      if (t.id === tradeId) {
        return {
          ...t,
          sl,
          tp
        };
      }
      return t;
    })
    );
  };
  const deposit = (amount: number, method: string) => {
    const tx: Transaction = {
      id: generateId(),
      type: 'DEPOSIT',
      amount,
      method,
      status: 'COMPLETED',
      date: Date.now()
    };
    setTransactions((prev) => [tx, ...prev]);
    setAccount((prev) => ({
      ...prev,
      balance: prev.balance + amount
    }));
  };
  const withdraw = (amount: number, method: string) => {
    const tx: Transaction = {
      id: generateId(),
      type: 'WITHDRAWAL',
      amount,
      method,
      status: 'PENDING',
      date: Date.now()
    };
    setTransactions((prev) => [tx, ...prev]);
    // Balance deduction usually happens on approval, but for MVP we can deduct immediately or wait
    // Let's deduct immediately for "Free Margin" impact
    setAccount((prev) => ({
      ...prev,
      balance: prev.balance - amount
    }));
  };
  const toggleBot = (active: boolean) => setBotActive(active);
  return (
    <StoreContext.Provider
      value={{
        user,
        account,
        assets,
        trades,
        history,
        transactions,
        signals,
        isAuthenticated: !!user,
        login,
        logout,
        executeTrade,
        closeTrade,
        modifyTradeSLTP,
        deposit,
        withdraw,
        toggleBot,
        botActive
      }}>

      {children}
    </StoreContext.Provider>);

}
export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
}