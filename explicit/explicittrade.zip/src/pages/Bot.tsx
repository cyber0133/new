import React from 'react';
import { useStore } from '../lib/store';
import {
  Bot,
  Zap,
  Shield,
  BarChart2,
  PlayCircle,
  StopCircle } from
'lucide-react';
export function BotPage() {
  const { botActive, toggleBot, trades } = useStore();
  const bots = [
  {
    name: 'Scalper Pro',
    type: 'High Frequency',
    risk: 'High',
    return: 124,
    price: 149.99,
    color: 'from-purple-500 to-pink-500'
  },
  {
    name: 'Trend Hunter V2',
    type: 'Swing Trading',
    risk: 'Medium',
    return: 45,
    price: 99.99,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    name: 'Gold Rush AI',
    type: 'Commodities',
    risk: 'Medium',
    return: 68,
    price: 199.99,
    color: 'from-yellow-500 to-orange-500'
  },
  {
    name: 'Smart Grid',
    type: 'Arbitrage',
    risk: 'Low',
    return: 12,
    price: 49.99,
    color: 'from-green-500 to-emerald-500'
  },
  {
    name: 'Neural Trader',
    type: 'AI Prediction',
    risk: 'High',
    return: 156,
    price: 299.99,
    color: 'from-red-500 to-rose-500'
  },
  {
    name: 'Crypto Momentum',
    type: 'Crypto Only',
    risk: 'High',
    return: 89,
    price: 'FREE TRIAL',
    color: 'from-indigo-500 to-violet-500'
  }];

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-10 pb-20 md:pb-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl md:text-3xl font-bold text-white">
          Bot Marketplace
        </h1>
        <p className="text-sm md:text-base text-[#8b949e]">
          Automate your trading with professional algorithms
        </p>
      </div>

      {/* Active Bot Section */}
      <div className="bg-[#161b22] border border-[#21262d] rounded-lg p-4 md:p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#2962ff]/20 rounded-lg">
              <Bot className="h-6 w-6 text-[#2962ff]" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">My Active Bot</h2>
              <p className="text-xs text-[#8b949e]">
                {botActive ?
                'Running: Scalper Pro' :
                'No bot currently running'}
              </p>
            </div>
          </div>
          <button
            onClick={() => toggleBot(!botActive)}
            className={`flex items-center justify-center gap-2 px-6 py-2 rounded font-bold transition-colors w-full md:w-auto ${botActive ? 'bg-[#ef5350]/20 text-[#ef5350] hover:bg-[#ef5350]/30' : 'bg-[#26a69a] text-white hover:bg-teal-600'}`}>

            {botActive ?
            <>
                <StopCircle className="h-4 w-4" /> Stop Bot
              </> :

            <>
                <PlayCircle className="h-4 w-4" /> Start Bot
              </>
            }
          </button>
        </div>

        {botActive &&
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#0d1117] p-4 rounded border border-[#21262d]">
              <span className="text-xs text-[#8b949e]">Total Trades</span>
              <span className="block text-xl font-mono text-white">24</span>
            </div>
            <div className="bg-[#0d1117] p-4 rounded border border-[#21262d]">
              <span className="text-xs text-[#8b949e]">Win Rate</span>
              <span className="block text-xl font-mono text-[#26a69a]">
                68%
              </span>
            </div>
            <div className="bg-[#0d1117] p-4 rounded border border-[#21262d]">
              <span className="text-xs text-[#8b949e]">Profit</span>
              <span className="block text-xl font-mono text-[#26a69a]">
                +$1,240.50
              </span>
            </div>
            <div className="bg-[#0d1117] p-4 rounded border border-[#21262d]">
              <span className="text-xs text-[#8b949e]">Status</span>
              <span className="block text-xl font-mono text-[#2962ff] animate-pulse">
                Active
              </span>
            </div>
          </div>
        }
      </div>

      {/* Marketplace Grid */}
      <div>
        <h3 className="text-xl font-bold text-white mb-6">Available Bots</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bots.map((bot) =>
          <div
            key={bot.name}
            className="bg-[#161b22] border border-[#21262d] rounded-lg overflow-hidden hover:border-[#2962ff] transition-colors group">

              <div className={`h-2 bg-gradient-to-r ${bot.color}`} />
              <div className="p-6 space-y-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-lg font-bold text-white group-hover:text-[#2962ff] transition-colors">
                      {bot.name}
                    </h4>
                    <span className="text-xs text-[#8b949e]">{bot.type}</span>
                  </div>
                  <span
                  className={`px-2 py-1 rounded text-xs font-bold ${bot.risk === 'High' ? 'bg-[#ef5350]/20 text-[#ef5350]' : bot.risk === 'Medium' ? 'bg-yellow-500/20 text-yellow-500' : 'bg-[#26a69a]/20 text-[#26a69a]'}`}>

                    {bot.risk} Risk
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-xs text-[#8b949e] flex items-center gap-1">
                      <Zap className="h-3 w-3" /> Return
                    </span>
                    <span className="text-lg font-bold text-[#26a69a]">
                      +{bot.return}%
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-[#8b949e] flex items-center gap-1">
                      <Shield className="h-3 w-3" /> Drawdown
                    </span>
                    <span className="text-lg font-bold text-white">12%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[#21262d]">
                  <span className="text-lg font-bold text-white">
                    {typeof bot.price === 'number' ?
                  `$${bot.price}/mo` :
                  bot.price}
                  </span>
                  <button
                  onClick={() => toggleBot(true)}
                  className="px-4 py-2 bg-[#2962ff] hover:bg-blue-600 text-white text-sm font-bold rounded transition-colors">

                    Buy Bot
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>);

}