import React, { useState } from 'react';
import { useStore } from '../lib/store';
import { Card } from '../components/ui/Card';
import { CheckCircle, TrendingUp, Users, Star, Filter } from 'lucide-react';
export function SignalsPage() {
  const { signals, executeTrade } = useStore();
  const [activeFilter, setActiveFilter] = useState('All');
  const traders = [
  {
    name: 'AlphaTrader',
    winRate: 87,
    return: 24.5,
    followers: 1240,
    avatar: 'bg-blue-500'
  },
  {
    name: 'FX_Master',
    winRate: 76,
    return: 18.2,
    followers: 890,
    avatar: 'bg-purple-500'
  },
  {
    name: 'CryptoKing',
    winRate: 92,
    return: 45.8,
    followers: 3100,
    avatar: 'bg-orange-500'
  },
  {
    name: 'GoldRush_Pro',
    winRate: 81,
    return: 21.0,
    followers: 650,
    avatar: 'bg-yellow-500'
  }];

  const handleBuySignal = (signal: any) => {
    executeTrade(signal.symbol, signal.type, 0.1, signal.sl, signal.tp);
    alert(
      `Successfully purchased signal from ${traders[Math.floor(Math.random() * traders.length)].name}`
    );
  };
  // Filter logic (mock implementation based on signal properties)
  const filteredSignals = signals.filter((s) => {
    if (activeFilter === 'All') return true;
    if (activeFilter === 'Forex')
    return (
      !s.symbol.includes('BTC') &&
      !s.symbol.includes('ETH') &&
      !s.symbol.includes('XAU'));

    if (activeFilter === 'Crypto')
    return s.symbol.includes('BTC') || s.symbol.includes('ETH');
    if (activeFilter === 'Commodities') return s.symbol.includes('XAU');
    if (activeFilter === 'Premium') return s.confidence > 85;
    return true;
  });
  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-8 pb-20 md:pb-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Signal Marketplace</h1>
        <p className="text-[#8b949e]">
          Copy trades from top performing traders instantly
        </p>
      </div>

      {/* Stats Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#161b22] border border-[#21262d] rounded-lg p-4">
        <div className="text-center border-r border-[#21262d] last:border-0">
          <span className="block text-xs text-[#8b949e] uppercase">
            Total Signals
          </span>
          <span className="block text-xl font-bold text-white">
            {signals.length}
          </span>
        </div>
        <div className="text-center border-r border-[#21262d] last:border-0">
          <span className="block text-xs text-[#8b949e] uppercase">
            Active Now
          </span>
          <span className="block text-xl font-bold text-[#26a69a]">12</span>
        </div>
        <div className="text-center border-r border-[#21262d] last:border-0">
          <span className="block text-xs text-[#8b949e] uppercase">
            Avg Win Rate
          </span>
          <span className="block text-xl font-bold text-[#2962ff]">78%</span>
        </div>
        <div className="text-center">
          <span className="block text-xs text-[#8b949e] uppercase">
            Top Trader
          </span>
          <span className="block text-xl font-bold text-purple-500">
            CryptoKing
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex overflow-x-auto no-scrollbar gap-2 pb-2">
        {['All', 'Forex', 'Crypto', 'Commodities', 'Premium'].map((filter) =>
        <button
          key={filter}
          onClick={() => setActiveFilter(filter)}
          className={`px-4 py-2 rounded-full border text-sm font-medium whitespace-nowrap transition-colors ${activeFilter === filter ? 'bg-[#2962ff] text-white border-[#2962ff]' : 'bg-[#161b22] border-[#21262d] text-[#8b949e] hover:text-white hover:border-[#8b949e]'}`}>

            {filter}
          </button>
        )}
      </div>

      {/* Signal Performance Mini Section */}
      <div className="bg-[#161b22] border border-[#21262d] rounded-lg p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#26a69a]/20 rounded-full">
            <TrendingUp className="h-5 w-5 text-[#26a69a]" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Recent Performance</h3>
            <p className="text-xs text-[#8b949e]">Last 24h accuracy</p>
          </div>
        </div>
        <div className="text-right">
          <span className="block font-bold text-[#26a69a] text-lg">92.4%</span>
          <span className="text-xs text-[#8b949e]">+1450 pips</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSignals.map((signal, idx) => {
          const trader = traders[idx % traders.length];
          const price =
          idx % 3 === 0 ? 'FREE' : `$${(Math.random() * 20 + 9).toFixed(2)}`;
          return (
            <div
              key={signal.id}
              className="bg-[#161b22] border border-[#21262d] rounded-lg overflow-hidden hover:border-[#2962ff] transition-colors group">

              {/* Trader Header */}
              <div className="p-4 border-b border-[#21262d] flex items-center justify-between bg-[#0d1117]">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full ${trader.avatar} flex items-center justify-center text-white font-bold`}>

                    {trader.name[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-white">
                        {trader.name}
                      </span>
                      <CheckCircle className="h-3 w-3 text-[#2962ff]" />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#8b949e]">
                      <span className="flex items-center gap-0.5">
                        <Users className="h-3 w-3" /> {trader.followers}
                      </span>
                      <span className="flex items-center gap-0.5 text-[#26a69a]">
                        <TrendingUp className="h-3 w-3" /> +{trader.return}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="block text-xs text-[#8b949e]">Win Rate</span>
                  <span className="block font-bold text-[#26a69a]">
                    {trader.winRate}%
                  </span>
                </div>
              </div>

              {/* Signal Details */}
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-white">
                    {signal.symbol}
                  </span>
                  <span
                    className={`px-3 py-1 rounded text-xs font-bold ${signal.type === 'BUY' ? 'bg-[#26a69a]/20 text-[#26a69a]' : 'bg-[#ef5350]/20 text-[#ef5350]'}`}>

                    {signal.type}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-[#0d1117] p-2 rounded border border-[#21262d]">
                    <span className="block text-[#8b949e]">Entry</span>
                    <span className="block font-mono text-white">
                      {signal.entry}
                    </span>
                  </div>
                  <div className="bg-[#0d1117] p-2 rounded border border-[#21262d]">
                    <span className="block text-[#8b949e]">SL</span>
                    <span className="block font-mono text-[#ef5350]">
                      {signal.sl}
                    </span>
                  </div>
                  <div className="bg-[#0d1117] p-2 rounded border border-[#21262d]">
                    <span className="block text-[#8b949e]">TP</span>
                    <span className="block font-mono text-[#26a69a]">
                      {signal.tp}
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#8b949e]">Confidence</span>
                    <span className="text-white">{signal.confidence}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#21262d] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#2962ff]"
                      style={{
                        width: `${signal.confidence}%`
                      }} />

                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-[#21262d] flex items-center justify-between bg-[#0d1117]">
                <span
                  className={`font-bold ${price === 'FREE' ? 'text-[#26a69a]' : 'text-white'}`}>

                  {price}
                </span>
                <button
                  onClick={() => handleBuySignal(signal)}
                  className="px-6 py-2 bg-[#26a69a] hover:bg-teal-600 text-white text-sm font-bold rounded transition-colors">

                  {price === 'FREE' ? 'Copy Signal' : 'Buy Signal'}
                </button>
              </div>
            </div>);

        })}
      </div>
    </div>);

}