import React, { useState } from 'react';
import { useStore } from '../lib/store';
import { formatCurrency, formatDate } from '../lib/utils';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Copy,
  CreditCard,
  Landmark,
  Bitcoin,
  CheckCircle,
  Clock,
  XCircle,
  Coins } from
'lucide-react';
export function WalletPage() {
  const { account, deposit, withdraw, transactions } = useStore();
  const [activeTab, setActiveTab] = useState<
    'deposit' | 'withdraw' | 'history'>(
    'deposit');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('crypto');
  const [selectedCrypto, setSelectedCrypto] = useState('USDT-TRC20');
  const [step, setStep] = useState(1);
  const cryptoOptions = [
  {
    id: 'BTC',
    name: 'Bitcoin',
    network: 'Bitcoin',
    address: 'bc1q...7x2',
    min: 0.001,
    icon: '₿'
  },
  {
    id: 'ETH',
    name: 'Ethereum',
    network: 'ERC-20',
    address: '0x3f...9a1',
    min: 0.01,
    icon: 'Ξ'
  },
  {
    id: 'USDT-TRC20',
    name: 'Tether',
    network: 'TRC-20',
    address: 'TQ8...3x9',
    min: 10,
    icon: '₮'
  },
  {
    id: 'USDT-ERC20',
    name: 'Tether',
    network: 'ERC-20',
    address: '0x3f...9a1',
    min: 10,
    icon: '₮'
  },
  {
    id: 'LTC',
    name: 'Litecoin',
    network: 'Litecoin',
    address: 'ltc1...m4k',
    min: 0.1,
    icon: 'Ł'
  },
  {
    id: 'XRP',
    name: 'Ripple',
    network: 'XRP Ledger',
    address: 'rN7...pQ2',
    tag: '12345',
    min: 20,
    icon: '✕'
  }];

  const handleDeposit = () => {
    if (!amount) return;
    deposit(parseFloat(amount), method);
    setStep(3);
    setTimeout(() => {
      setStep(1);
      setAmount('');
      alert('Deposit successful');
    }, 2000);
  };
  const handleWithdraw = () => {
    if (!amount) return;
    withdraw(parseFloat(amount), method);
    setStep(3);
    setTimeout(() => {
      setStep(1);
      setAmount('');
      alert('Withdrawal request submitted');
    }, 2000);
  };
  const currentCrypto = cryptoOptions.find((c) => c.id === selectedCrypto);
  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6 space-y-8 pb-20 md:pb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">Wallet & Funds</h1>
        <div className="flex bg-[#161b22] p-1 rounded border border-[#21262d] overflow-x-auto no-scrollbar">
          {['deposit', 'withdraw', 'history'].map((tab) =>
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab as any);
              setStep(1);
            }}
            className={`px-4 md:px-6 py-2 text-sm font-bold rounded capitalize transition-all whitespace-nowrap ${activeTab === tab ? 'bg-[#2962ff] text-white shadow-lg' : 'text-[#8b949e] hover:text-white'}`}>

              {tab}
            </button>
          )}
        </div>
      </div>

      {activeTab === 'deposit' &&
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Step Indicator */}
            <div className="flex items-center justify-between mb-8">
              {[1, 2, 3].map((s) =>
            <div key={s} className="flex items-center">
                  <div
                className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step >= s ? 'bg-[#26a69a] text-white' : 'bg-[#21262d] text-[#8b949e]'}`}>

                    {s}
                  </div>
                  {s < 3 &&
              <div
                className={`w-12 md:w-24 h-1 mx-2 ${step > s ? 'bg-[#26a69a]' : 'bg-[#21262d]'}`} />

              }
                </div>
            )}
            </div>

            {step === 1 &&
          <div className="bg-[#161b22] border border-[#21262d] rounded p-6">
                <h3 className="text-lg font-bold text-white mb-4">
                  Select Amount
                </h3>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {[100, 250, 500, 1000, 5000, 10000].map((val) =>
              <button
                key={val}
                onClick={() => setAmount(val.toString())}
                className={`p-2 md:p-4 border rounded text-sm md:text-lg font-mono font-bold transition-all ${amount === val.toString() ? 'border-[#26a69a] bg-[#26a69a]/10 text-[#26a69a]' : 'border-[#21262d] bg-[#0d1117] text-white hover:border-[#8b949e]'}`}>

                      ${val}
                    </button>
              )}
                </div>
                <div className="mb-6">
                  <label className="block text-xs text-[#8b949e] mb-2">
                    Custom Amount
                  </label>
                  <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[#0d1117] border border-[#21262d] rounded p-3 text-white font-mono text-xl focus:border-[#26a69a] focus:outline-none"
                placeholder="0.00" />

                </div>
                <button
              onClick={() => amount && setStep(2)}
              className="w-full py-4 bg-[#26a69a] hover:bg-teal-600 text-white font-bold rounded transition-colors">

                  Continue
                </button>
              </div>
          }

            {step === 2 &&
          <div className="bg-[#161b22] border border-[#21262d] rounded p-6">
                <h3 className="text-lg font-bold text-white mb-4">
                  Select Payment Method
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {[
              {
                id: 'crypto',
                label: 'Crypto',
                icon: Bitcoin
              },
              {
                id: 'card',
                label: 'Credit Card',
                icon: CreditCard
              },
              {
                id: 'bank',
                label: 'Bank Transfer',
                icon: Landmark
              }].
              map((m) =>
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`p-4 md:p-6 border rounded flex flex-col items-center justify-center gap-3 transition-all ${method === m.id ? 'border-[#2962ff] bg-[#2962ff]/10 text-white' : 'border-[#21262d] bg-[#0d1117] text-[#8b949e] hover:border-[#8b949e]'}`}>

                      <m.icon className="h-6 w-6 md:h-8 md:w-8" />
                      <span className="font-bold text-sm md:text-base">
                        {m.label}
                      </span>
                    </button>
              )}
                </div>

                {method === 'crypto' &&
            <div className="space-y-4 mb-6">
                    <label className="block text-xs text-[#8b949e]">
                      Select Cryptocurrency
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {cryptoOptions.map((crypto) =>
                <button
                  key={crypto.id}
                  onClick={() => setSelectedCrypto(crypto.id)}
                  className={`p-3 border rounded flex flex-col items-center gap-1 transition-all ${selectedCrypto === crypto.id ? 'border-[#26a69a] bg-[#26a69a]/10 text-white' : 'border-[#21262d] bg-[#0d1117] text-[#8b949e]'}`}>

                          <span className="text-xl">{crypto.icon}</span>
                          <span className="text-xs font-bold">{crypto.id}</span>
                          <span className="text-[10px] text-[#8b949e]">
                            {crypto.network}
                          </span>
                        </button>
                )}
                    </div>

                    <div className="bg-[#0d1117] p-4 rounded border border-[#21262d]">
                      <p className="text-xs text-[#8b949e] mb-2">
                        Send {currentCrypto?.name} ({currentCrypto?.network})
                        to:
                      </p>
                      <div className="flex items-center justify-between bg-[#161b22] p-3 rounded border border-[#21262d] mb-2">
                        <code className="text-[#26a69a] font-mono text-xs md:text-sm break-all">
                          {currentCrypto?.address}
                        </code>
                        <button className="text-[#8b949e] hover:text-white ml-2 flex-shrink-0">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      {currentCrypto?.tag &&
                <div className="flex items-center justify-between bg-[#161b22] p-3 rounded border border-[#21262d]">
                          <span className="text-[#8b949e] text-xs">
                            Destination Tag:
                          </span>
                          <code className="text-white font-mono text-sm">
                            {currentCrypto.tag}
                          </code>
                        </div>
                }
                      <div className="mt-3 flex justify-between text-xs text-[#8b949e]">
                        <span>
                          Min Deposit: {currentCrypto?.min} {currentCrypto?.id}
                        </span>
                        <span>Est. Time: ~10 mins</span>
                      </div>
                    </div>
                  </div>
            }

                <div className="flex gap-4">
                  <button
                onClick={() => setStep(1)}
                className="flex-1 py-4 border border-[#21262d] text-white font-bold rounded hover:bg-[#21262d]">

                    Back
                  </button>
                  <button
                onClick={handleDeposit}
                className="flex-1 py-4 bg-[#26a69a] hover:bg-teal-600 text-white font-bold rounded">

                    Confirm Deposit ${amount}
                  </button>
                </div>
              </div>
          }

            {step === 3 &&
          <div className="bg-[#161b22] border border-[#21262d] rounded p-12 text-center">
                <div className="w-16 h-16 bg-[#26a69a]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="h-8 w-8 text-[#26a69a]" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  Deposit Successful!
                </h3>
                <p className="text-[#8b949e]">
                  Your funds have been added to your trading account.
                </p>
              </div>
          }
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#161b22] to-[#0d1117] border border-[#21262d] rounded p-6">
              <p className="text-sm text-[#8b949e] mb-1">Current Balance</p>
              <p className="text-3xl font-mono font-bold text-white mb-4">
                {formatCurrency(account.balance)}
              </p>
              <div className="flex gap-2 text-xs text-[#8b949e]">
                <span className="px-2 py-1 bg-[#26a69a]/10 text-[#26a69a] rounded">
                  Active
                </span>
                <span className="px-2 py-1 bg-[#21262d] rounded">Verified</span>
              </div>
            </div>

            <div className="bg-[#161b22] border border-[#21262d] rounded p-6">
              <h4 className="font-bold text-white mb-4">Important Notes</h4>
              <ul className="space-y-2 text-sm text-[#8b949e]">
                <li>• Minimum deposit is $100</li>
                <li>• Crypto deposits require 1 confirmation</li>
                <li>• Bank transfers take 1-3 business days</li>
              </ul>
            </div>
          </div>
        </div>
      }

      {activeTab === 'withdraw' &&
      <div className="max-w-2xl mx-auto bg-[#161b22] border border-[#21262d] rounded p-8">
          <h3 className="text-xl font-bold text-white mb-6">
            Request Withdrawal
          </h3>
          <div className="space-y-6">
            <div>
              <label className="block text-xs text-[#8b949e] mb-2">
                Withdrawal Amount
              </label>
              <div className="relative">
                <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[#0d1117] border border-[#21262d] rounded p-3 text-white font-mono text-xl focus:border-[#ef5350] focus:outline-none"
                placeholder="0.00" />

                <div className="absolute right-2 top-2 flex gap-1">
                  {[25, 50, 100].map((pct) =>
                <button
                  key={pct}
                  onClick={() =>
                  setAmount((account.freeMargin * (pct / 100)).toFixed(2))
                  }
                  className="px-2 py-1 text-xs bg-[#21262d] text-white rounded hover:bg-[#30363d]">

                      {pct}%
                    </button>
                )}
                </div>
              </div>
              <p className="text-xs text-[#8b949e] mt-2">
                Available: {formatCurrency(account.freeMargin)}
              </p>
            </div>

            <div>
              <label className="block text-xs text-[#8b949e] mb-2">
                Destination Address
              </label>
              <input
              type="text"
              className="w-full bg-[#0d1117] border border-[#21262d] rounded p-3 text-white focus:border-[#ef5350] focus:outline-none"
              placeholder="Wallet Address or IBAN" />

            </div>

            <button
            onClick={handleWithdraw}
            className="w-full py-4 bg-[#ef5350] hover:bg-red-600 text-white font-bold rounded transition-colors">

              Request Withdrawal
            </button>
          </div>
        </div>
      }

      {activeTab === 'history' &&
      <div className="bg-[#161b22] border border-[#21262d] rounded overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left min-w-[600px]">
              <thead className="bg-[#0d1117] text-[#8b949e] text-xs uppercase">
                <tr>
                  <th className="px-6 py-3">Type</th>
                  <th className="px-6 py-3">Amount</th>
                  <th className="px-6 py-3">Method</th>
                  <th className="px-6 py-3">Date</th>
                  <th className="px-6 py-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {transactions.map((tx) =>
              <tr key={tx.id} className="hover:bg-[#1c2128]">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {tx.type === 'DEPOSIT' ?
                    <ArrowDownLeft className="h-4 w-4 text-[#26a69a]" /> :

                    <ArrowUpRight className="h-4 w-4 text-[#ef5350]" />
                    }
                        <span className="font-bold text-white">{tx.type}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-mono text-white">
                      {formatCurrency(tx.amount)}
                    </td>
                    <td className="px-6 py-4 text-[#8b949e] capitalize">
                      {tx.method}
                    </td>
                    <td className="px-6 py-4 text-[#8b949e]">
                      {formatDate(tx.date)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span
                    className={`px-2 py-1 rounded text-xs font-bold ${tx.status === 'COMPLETED' ? 'bg-[#26a69a]/10 text-[#26a69a]' : tx.status === 'PENDING' ? 'bg-yellow-500/10 text-yellow-500' : 'bg-[#ef5350]/10 text-[#ef5350]'}`}>

                        {tx.status}
                      </span>
                    </td>
                  </tr>
              )}
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>);

}