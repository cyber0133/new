import React, { useCallback, useEffect, useState, useRef } from 'react';
import { useStore } from '../../lib/store';
interface ChartProps {
  symbol: string;
}
interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
export function Chart({ symbol }: ChartProps) {
  const { assets } = useStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [timeframe, setTimeframe] = useState('H1');
  const [candles, setCandles] = useState<Candle[]>([]);
  const [mousePos, setMousePos] = useState<{
    x: number;
    y: number;
  } | null>(null);
  const [dimensions, setDimensions] = useState({
    width: 800,
    height: 400
  });
  const asset = assets.find((a) => a.symbol === symbol);
  // Generate OHLC candle data
  const generateCandles = useCallback(
    (basePrice: number, count: number = 120) => {
      const data: Candle[] = [];
      const now = Date.now();
      let open = basePrice * (1 + (Math.random() - 0.5) * 0.02);
      for (let i = count; i > 0; i--) {
        const volatility = basePrice * 0.0015;
        const direction = Math.random() - 0.48; // slight upward bias
        const range = Math.random() * volatility;
        const close = open + direction * range;
        const wickUp = Math.random() * volatility * 0.4;
        const wickDown = Math.random() * volatility * 0.4;
        const high = Math.max(open, close) + wickUp;
        const low = Math.min(open, close) - wickDown;
        data.push({
          time: now - i * 3600000,
          open,
          high,
          low,
          close,
          volume: Math.floor(Math.random() * 1000) + 200
        });
        open = close;
      }
      return data;
    },
    []
  );
  // Initialize candles when symbol or timeframe changes
  useEffect(() => {
    if (!asset) return;
    setCandles(generateCandles(asset.bid));
  }, [symbol, timeframe, asset?.symbol]);
  // Live update: modify the last candle with current price
  useEffect(() => {
    if (!asset || candles.length === 0) return;
    setCandles((prev) => {
      const updated = [...prev];
      const last = {
        ...updated[updated.length - 1]
      };
      last.close = asset.bid;
      last.high = Math.max(last.high, asset.bid);
      last.low = Math.min(last.low, asset.bid);
      updated[updated.length - 1] = last;
      return updated;
    });
  }, [asset?.bid]);
  // Handle resize
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setDimensions({
          width: Math.floor(width),
          height: Math.floor(height)
        });
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);
  // Draw the chart
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = dimensions.width * dpr;
    canvas.height = dimensions.height * dpr;
    ctx.scale(dpr, dpr);
    const W = dimensions.width;
    const H = dimensions.height;
    const PRICE_SCALE_W = 70;
    const TIME_SCALE_H = 28;
    const chartW = W - PRICE_SCALE_W;
    const chartH = H - TIME_SCALE_H;
    // Clear
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(0, 0, W, H);
    // Calculate price range
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    for (const c of candles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    }
    const priceRange = maxPrice - minPrice;
    const padding = priceRange * 0.08;
    minPrice -= padding;
    maxPrice += padding;
    const totalRange = maxPrice - minPrice;
    const priceToY = (price: number) => {
      return chartH - (price - minPrice) / totalRange * chartH;
    };
    const candleWidth = Math.max(2, Math.floor(chartW / candles.length * 0.7));
    const candleSpacing = chartW / candles.length;
    // Grid lines (horizontal)
    const gridLines = 8;
    ctx.strokeStyle = '#21262d';
    ctx.lineWidth = 1;
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillStyle = '#8b949e';
    ctx.textAlign = 'left';
    for (let i = 0; i <= gridLines; i++) {
      const price = minPrice + totalRange / gridLines * i;
      const y = Math.round(priceToY(price)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartW, y);
      ctx.stroke();
      // Price labels on right scale
      const digits = asset?.digits || 2;
      ctx.fillText(price.toFixed(digits), chartW + 8, y + 3);
    }
    // Grid lines (vertical) — every ~20 candles
    const vStep = Math.max(1, Math.floor(candles.length / 6));
    for (let i = 0; i < candles.length; i += vStep) {
      const x = Math.round(i * candleSpacing + candleSpacing / 2) + 0.5;
      ctx.beginPath();
      ctx.strokeStyle = '#21262d';
      ctx.moveTo(x, 0);
      ctx.lineTo(x, chartH);
      ctx.stroke();
      // Time labels
      const date = new Date(candles[i].time);
      const label = `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
      ctx.fillStyle = '#8b949e';
      ctx.textAlign = 'center';
      ctx.fillText(label, x, chartH + 16);
    }
    // Draw candles
    for (let i = 0; i < candles.length; i++) {
      const c = candles[i];
      const x = i * candleSpacing + candleSpacing / 2;
      const isUp = c.close >= c.open;
      const color = isUp ? '#26a69a' : '#ef5350';
      const bodyTop = priceToY(Math.max(c.open, c.close));
      const bodyBottom = priceToY(Math.min(c.open, c.close));
      const bodyHeight = Math.max(1, bodyBottom - bodyTop);
      // Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, priceToY(c.high));
      ctx.lineTo(Math.round(x) + 0.5, priceToY(c.low));
      ctx.stroke();
      // Body
      ctx.fillStyle = color;
      ctx.fillRect(
        Math.round(x - candleWidth / 2),
        Math.round(bodyTop),
        candleWidth,
        Math.round(bodyHeight)
      );
    }
    // Current price line
    if (asset) {
      const currentY = priceToY(asset.bid);
      ctx.strokeStyle = '#2962ff';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(0, Math.round(currentY) + 0.5);
      ctx.lineTo(chartW, Math.round(currentY) + 0.5);
      ctx.stroke();
      ctx.setLineDash([]);
      // Price label box
      ctx.fillStyle = '#2962ff';
      const labelY = Math.round(currentY);
      ctx.fillRect(chartW, labelY - 9, PRICE_SCALE_W, 18);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px JetBrains Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(asset.bid.toFixed(asset.digits), chartW + 6, labelY + 4);
    }
    // Crosshair
    if (mousePos && mousePos.x < chartW && mousePos.y < chartH) {
      ctx.strokeStyle = '#484f58';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      // Vertical line
      ctx.beginPath();
      ctx.moveTo(Math.round(mousePos.x) + 0.5, 0);
      ctx.lineTo(Math.round(mousePos.x) + 0.5, chartH);
      ctx.stroke();
      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, Math.round(mousePos.y) + 0.5);
      ctx.lineTo(chartW, Math.round(mousePos.y) + 0.5);
      ctx.stroke();
      ctx.setLineDash([]);
      // Price at cursor
      const cursorPrice = maxPrice - mousePos.y / chartH * totalRange;
      const digits = asset?.digits || 2;
      ctx.fillStyle = '#30363d';
      ctx.fillRect(chartW, Math.round(mousePos.y) - 9, PRICE_SCALE_W, 18);
      ctx.fillStyle = '#c9d1d9';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(
        cursorPrice.toFixed(digits),
        chartW + 6,
        Math.round(mousePos.y) + 4
      );
      // OHLC tooltip at top
      const candleIdx = Math.min(
        candles.length - 1,
        Math.max(0, Math.floor(mousePos.x / candleSpacing))
      );
      const hoverCandle = candles[candleIdx];
      if (hoverCandle) {
        const d = asset?.digits || 2;
        ctx.font = '11px JetBrains Mono, monospace';
        ctx.textAlign = 'left';
        const ohlcY = 14;
        ctx.fillStyle = '#8b949e';
        ctx.fillText('O ', 8, ohlcY);
        ctx.fillStyle =
        hoverCandle.close >= hoverCandle.open ? '#26a69a' : '#ef5350';
        ctx.fillText(hoverCandle.open.toFixed(d), 22, ohlcY);
        ctx.fillStyle = '#8b949e';
        ctx.fillText('H ', 22 + (d + 2) * 7.5, ohlcY);
        ctx.fillStyle =
        hoverCandle.close >= hoverCandle.open ? '#26a69a' : '#ef5350';
        ctx.fillText(hoverCandle.high.toFixed(d), 36 + (d + 2) * 7.5, ohlcY);
        ctx.fillStyle = '#8b949e';
        ctx.fillText('L ', 36 + (d + 2) * 15, ohlcY);
        ctx.fillStyle =
        hoverCandle.close >= hoverCandle.open ? '#26a69a' : '#ef5350';
        ctx.fillText(hoverCandle.low.toFixed(d), 50 + (d + 2) * 15, ohlcY);
        ctx.fillStyle = '#8b949e';
        ctx.fillText('C ', 50 + (d + 2) * 22.5, ohlcY);
        ctx.fillStyle =
        hoverCandle.close >= hoverCandle.open ? '#26a69a' : '#ef5350';
        ctx.fillText(hoverCandle.close.toFixed(d), 64 + (d + 2) * 22.5, ohlcY);
      }
    }
    // Right scale border
    ctx.strokeStyle = '#21262d';
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(chartW + 0.5, 0);
    ctx.lineTo(chartW + 0.5, H);
    ctx.stroke();
    // Bottom scale border
    ctx.beginPath();
    ctx.moveTo(0, chartH + 0.5);
    ctx.lineTo(W, chartH + 0.5);
    ctx.stroke();
  }, [candles, dimensions, mousePos, asset]);
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };
  const handleMouseLeave = () => setMousePos(null);
  return (
    <div className="flex flex-col h-full bg-[#0d1117]">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#21262d] bg-[#161b22] flex-shrink-0">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-bold text-white">{symbol}</h2>
          <div className="flex items-center space-x-2 text-sm font-mono">
            <span className="text-[#26a69a]">
              {asset?.bid.toFixed(asset?.digits)}
            </span>
            <span className="text-[#8b949e]">/</span>
            <span className="text-[#ef5350]">
              {asset?.ask.toFixed(asset?.digits)}
            </span>
          </div>
        </div>
        <div className="flex space-x-1">
          {['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1'].map((tf) =>
          <button
            key={tf}
            onClick={() => setTimeframe(tf)}
            className={`px-2 py-1 text-xs font-medium rounded ${timeframe === tf ? 'bg-[#2962ff] text-white' : 'text-[#8b949e] hover:bg-[#21262d] hover:text-white'}`}>

              {tf}
            </button>
          )}
        </div>
      </div>

      {/* Canvas Chart */}
      <div ref={containerRef} className="flex-1 relative min-h-0">
        <canvas
          ref={canvasRef}
          width={dimensions.width}
          height={dimensions.height}
          style={{
            width: dimensions.width,
            height: dimensions.height
          }}
          className="block"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave} />

      </div>
    </div>);

}